# Sambra Premier League – Docker

Folder layout:

    spl-docker/
      Dockerfile
      docker-compose.yml
      site/
        index.html      <- the app

## Run

    docker compose up -d --build

Open:
- http://localhost:8080/
- http://localhost:8080/2026/

## Open on your phone (same Wi-Fi)

1. Find your computer's IP address (e.g. 192.168.1.20).
2. On the phone open http://192.168.1.20:8080/

## Stop

    docker compose down

## Without compose

    docker build -t spl .
    docker run -d -p 8080:80 --name spl spl

## Note

Data is saved in each browser (localStorage), not in the container. A different
address (or port) means a separate, empty ledger. Use "Save backup" after every
match day.
